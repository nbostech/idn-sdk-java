# wavelabs-java-client-api
wavelabs java client api 

// gradle clean
// gradle aCJar aCSJar aCDJar sACJar sACSJar sACDJar gPomFileFACP
// gradle --rerun-tasks signApiClientPomF
// gradle pACPublicationToProjR
// gradle pACPublicationToNbosMavenR
// gradle pACPublicationToMaven2R
