package com.nbos.capi.api.v0;


public class RestMessage {

    public String getMessageCode() {
        return messageCode;
    }

    public String getMessage() {
        return message;
    }

    String messageCode;
    String message;

}
