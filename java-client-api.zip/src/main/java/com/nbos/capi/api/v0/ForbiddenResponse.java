package com.nbos.capi.api.v0;


public class ForbiddenResponse extends RestMessage {
}
