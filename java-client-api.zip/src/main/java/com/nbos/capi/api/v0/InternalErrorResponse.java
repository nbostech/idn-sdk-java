package com.nbos.capi.api.v0;

public class InternalErrorResponse extends RestMessage {
}
