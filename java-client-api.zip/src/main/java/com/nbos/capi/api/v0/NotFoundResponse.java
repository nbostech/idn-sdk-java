package com.nbos.capi.api.v0;

public class NotFoundResponse extends RestMessage {
}
