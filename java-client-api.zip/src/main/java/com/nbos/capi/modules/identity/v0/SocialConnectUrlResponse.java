package com.nbos.capi.modules.identity.v0;



public class SocialConnectUrlResponse {
    public String getUrl() {
        return url;
    }

    String url;
}
