package com.nbos.capi.modules.identity.v0;


import com.nbos.capi.api.v0.RestMessage;

public class SocialConnectErrorResponse extends RestMessage {

}
