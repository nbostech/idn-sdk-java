package com.nbos.capi.modules.media.v0;

/**
 * Created by vineeln on 5/21/16.
 */
public class MediaFileDetails {
    public String getMediapath() {
        return mediapath;
    }

    public String getMediatype() {
        return mediatype;
    }

    private String mediapath;
    private String mediatype;
}
