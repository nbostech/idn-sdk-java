package com.nbos.capi.modules.media.v0;

public class MediaDetails {
    private int width;

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    public String getMediatype() {
        return mediatype;
    }

    private int height;
    private String mediatype;

}