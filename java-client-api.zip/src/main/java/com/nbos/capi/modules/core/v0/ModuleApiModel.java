package com.nbos.capi.modules.core.v0;

public class ModuleApiModel {
    public String getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    String uuid;
    String name;
}
