package com.nbos.capi.modules.ids.v0;

/**
 * Created by vivekkiran on 6/23/16.
 */
// Retrofit Api Interface
public interface IdsRemoteApi {

}
