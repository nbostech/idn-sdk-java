package in.wavelabs.idn.utils;

/**
 * Created by Vivek on 6/22/15.
 */
public class Constants {
    public static final String MAIN = "http://api.qa1.nbos.in/";
}

