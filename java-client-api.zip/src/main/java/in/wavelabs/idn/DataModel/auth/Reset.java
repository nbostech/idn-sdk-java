package in.wavelabs.idn.DataModel.auth;

/**
 * Created by vineelanalla on 14/01/16.
 */
public class Reset {
    public void setEmail(String email) {
        this.email = email;
    }

    private String email;

}
