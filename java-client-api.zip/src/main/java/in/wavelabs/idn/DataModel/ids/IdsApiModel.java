package in.wavelabs.idn.DataModel.ids;

/**
 * Created by vivekkiran on 6/17/16.
 */

public class IdsApiModel {
    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    String host;
}
